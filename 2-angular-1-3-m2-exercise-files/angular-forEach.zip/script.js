// Code goes here

angular.module('app', ['ngRoute']).config(function($routeProvider) {
  $routeProvider.when('/classes', {
    id: 'classes',
    templateUrl: 'classes.html',
    controller: 'classesCtrl'
  }).when('/students', {
    id: 'students',
    templateUrl: 'students.html',
    controller: 'studentsCtrl'
  }).otherwise('/classes')
})

function iterateWithConsoleLog(item, idx, collection) {
  console.log(item, collection);
}

angular.module('app').controller('mainCtrl', function($scope, $rootScope, classes, students) {
  $scope.classes = classes.classList;
  $scope.students = students.studentList;
  var students = {
    'bilbo@hobbits.com': { /* bilbo student here*/ },
    'sam@hobbits.com': { /* sam student here */ }
  }
  
  $scope.iterateStudents = function() {
    angular.forEach(students, iterateWithConsoleLog)
  }
  
});
angular.module('app').controller('classesCtrl', function($scope) {
});
angular.module('app').controller('studentsCtrl', function($scope) {
  
});