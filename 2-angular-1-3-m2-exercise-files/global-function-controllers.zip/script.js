// Code goes here

angular.module('app', []);

function mainCtrl($scope) {
  $scope.selectedClass = "Hobbits 101";
}

angular.module('app').config(function($controllerProvider) {
  $controllerProvider.allowGlobals();
})