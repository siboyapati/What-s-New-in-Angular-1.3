// Code goes here

angular.module('app', ['ngRoute']).config(function($routeProvider) {
  $routeProvider.when('/classes', {
    id: 'classes',
    templateUrl: 'classes.html',
    controller: 'classesCtrl'
  }).when('/students', {
    id: 'students',
    templateUrl: 'students.html',
    controller: 'studentsCtrl'
  }).when('/yourgrade', {
    id: 'grade',
    templateUrl: 'grade.html',
    controller: 'gradeCtrl'
  }).otherwise('/classes')
})
 
angular.module('app').controller('mainCtrl', function($scope, classes, students) {
  $scope.classes = classes.classList;
  $scope.students = students.studentList;
});
angular.module('app').controller('gradeCtrl', function($scope, gradeData) {
  gradeData.getGradeNew().then(function(grade) {
    $scope.grade = grade;
  }, function(msg) {
    $scope.error = msg;
  })
});

angular.module('app').service('gradeData', function($q) {
  return {
    getGradeOld: function() {
      var dfd = $q.defer();
      realtimeData.getGrade(4, function(grade) {
        if(grade != 'F') {
          dfd.resolve(grade);
        } else {
          dfd.reject('You shall not pass!');
        }
      });
      return dfd.promise;
    },
    getGradeNew: function() {
      var promise = $q(function(resolve, reject) {
        realtimeData.getGrade(3, function(grade) {
          if(grade != 'F') {
            resolve(grade);
          } else {
            reject('You shall not pass!');
          }
        });
      });
      return promise;
    }
  }
})
angular.module('app').controller('classesCtrl', function($scope) {

});
angular.module('app').controller('studentsCtrl', function($scope) {

});

var realtimeData = {
  getGrade: function(studentId, cb) {
    setTimeout(function() {
      if(studentId === 3) {
        cb('A');
      } else {
        cb('F');
      }
    })
  }  
}













