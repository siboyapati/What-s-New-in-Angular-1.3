angular.module('app', []).controller('randomStudentCtrl', function($scope, $http) {
  var randomStudentId = Math.random() * 101;
  $http.get('students/' + randomStudentId).then(function(response) {
    $scope.currentStudent = response.data;
  });
  
  var unWatch = $scope.$watch('currentStudent', function() {
    // implementation
  });
  
  $scope.stopWatching = function() {
    unWatch();
  }
});

function randomStudentUrlMatcher(url) {
  if(url.substr(0, 9) === 'students/') {
    return true;
  } else {
    return false; 
  }
}

describe('randomStudentCtrl', function() {
    var $controller;

    beforeEach(module('app'));

    beforeEach(inject(function(_$controller_) {
      $controller = _$controller_;
    }));

    describe('load', function() {
      it('should get data from the correct endpoint', inject(function($httpBackend, $rootScope) {
        
        var scope = $rootScope.$new();
        var controller = $controller('randomStudentCtrl', { $scope: scope });
        var mockStudent = {name: 'Bilbo Baggins', gpa: 0.8}
        
        $httpBackend.expectGET(randomStudentUrlMatcher).respond(200, mockStudent);
        $httpBackend.flush();

        expect($rootScope.$countWatchers()).toEqual(1);
        scope.stopWatching();
        expect($rootScope.$countWatchers()).toEqual(0);
        expect($rootScope.$countChildScopes()).toEqual(1);
        
        expect(scope.currentStudent).toEqual(mockStudent)
      }));
    });
});
